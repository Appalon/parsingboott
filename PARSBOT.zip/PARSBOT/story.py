import telebot

from telebot import types
from data_text import Read

TOKEN = '6026509519:AAGJ4TQcYwtDWAyf-gZ-PN2FMzN5IPYcSbs'

bot = telebot.TeleBot(TOKEN)

kivano = Read('/home/baiel/Рабочий стол/PARSBOT/kivano/tyu.csv')

@bot.message_handler(commands=["start"])
def start(message):
    markup = types.ReplyKeyboardMarkup(True,False)
    markup.row("/start", "/stop")
    markup.row("/about","/store")
    bot.send_message(message.chat.id, "WELCOME!",
    reply_markup=markup)

@bot.message_handler(commands=["start"])
def start(message):
    markup = types.ReplyKeyboardMarkup(True,False)
    markup.row("/start","/stop")
    markup.row("/about","/store")
    bot.send_message(message.chat.id, "Добро пожаловать!",reply_markup=markup)


@bot.message_handler(commands=["stop"])
def stop(message):
    markup = types.ReplyKeyboardRemove()
    bot.send_message(message.chat.id, "давай до свидания",reply_markup=markup)

@bot.message_handler(commands=["about"])
def about(message):
    bot.send_message(message.chat.id, f'Это бот {bot.get_me().first_name}\nТвое имя:{message.from_user.username}\n\
    Маркетплейс с десятками видов гаджетов для жизни, которые можно купить в Бишкеке, а также c доставкой по Кыргызстану (Ош, Баткен, Джалал-Абад, Каракол, Талас, Нарын) и заграницу (Россия и Казахстан) по низким ценам, либо в кредит (рассрочка). Цены на товары такие же и даже дешевле, чем в магазинах города (ЦУМ, ГУМ и т.п.) или на рынке Дордой.', parse_mode='html')    


@bot.message_handler(commands=["store"])
def store(message):
    markup = types.ReplyKeyboardMarkup(True,False)
    markup.row("Kivano")
    bot.send_message(message.chat.id, "Магазин Kivano, приветствует тебя",reply_markup=markup)

@bot.message_handler(content_types=["text"])
def text(message):
    if message.text == "Kivano":
        markup = types.InlineKeyboardMarkup()
        laptop = types.InlineKeyboardButton("Ноутбуки", callback_data="aaa")
        markup.add(laptop)
        bot.send_message(message.chat.id,"Выберите ноут", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: True)
def callback_inline(call):
    
    if call.message:
            if call.data == 'aaa':
                file = kivano
                for name in file.read_csv('Название'):
                    names = "{}".format(name)
                    for price in file.read_csv('Цена'):
                        prices = "Цена: {}".format(price)
                        for image in file.read_csv('Изображение'):
                            info = f'{names} {prices}'
                            markup = types.InlineKeyboardMarkup(row_width=2)
                            buy = types.InlineKeyboardButton('Купить', callback_data='buy')
                            markup.add(buy)
                            bot.send_photo(call.from_user.id, image)
                            bot.send_message(call.message.chat.id, info, reply_markup=markup)
                            import time 
                            time.sleep(2)

    
bot.polling(non_stop=True)