import csv

import requests
from bs4 import BeautifulSoup


class Parser:
    HEADERS = {
        'Accept': 'text/html, application/xhtml+xml, application/xml;q=0.9, */*;q=0.8'
        'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.61 Safari/537.36'
    }
    HOST = 'https://www.kivano.kg'


    def __init__(self, url, path) -> None:
        self.url = url
        self.path = path

    def get_html(self):
        request = requests.get(self.url, headers=self.HEADERS)
        return request.text

    def get_content(self, html):
        soup = BeautifulSoup(html, 'html.parser')
        items = soup.find_all('div', class_ = 'item product_listbox oh')
        new_list = []
        for item in items:
            new_list.append({
                'title': item.find('div', class_='listbox_title oh').find('a').get_text(strip=True),
                'price': item.find('div', class_= 'listbox_price text-center').get_text(strip=True),
                'images': self.HOST + item.find('div', class_='listbox_img pull-left').find('img').get('src')
            })
        return new_list
    
    def save_txt(self, items):
        with open(self.path, 'w') as file:
            for item in items:
                file.write(f"Название:{item['title']}, Цена:{item['price']}\n")

    def save(self, items):
        with open(self.path, 'w') as file:
            writer = csv.writer(file, delimiter=',')
            writer.writerow(['Название', 'Цена', 'Изображение'])
            for item in items:
                writer.writerow([item['title'], item['price'], item['images']])


parser = Parser(
    url='https://www.kivano.kg/{}'.format(input('name category:')), 
    path='{}.csv'.format(input('name file:'))
)
request = parser.get_html()
content = parser.get_content(request)
parser.save(content)
                
