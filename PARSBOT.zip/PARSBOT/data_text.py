import csv
class Read:
    def __init__(self,path) -> None:
        self.path = path

    def read_csv(self,key):
        with open(self.path,'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                yield row[key]

    def read_name(self):
        for i in self.read_csv( key= 'Называния'):
            yield i

    def read_price(self):
        for i in self.read_csv( key= 'цена'):
            yield i

    def read_image(self):
        for i in self.read_csv( key= 'изоброжения'):
            yield i

    def read_data(self):
        with open(self.path,'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                yield row